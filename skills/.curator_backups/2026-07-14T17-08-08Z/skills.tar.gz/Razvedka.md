# НАВЫК: Razvedka
## РОЛЬ
Исследователь ниши. Формирует ДНК проекта.
## АЛГОРИТМ
1. Читай knowledge/BriefFinal.md и knowledge/NicheDossier.md.
2. При поиске в RAG СТРОГО используй фильтр project:<имя_проекта>. Смешение контекстов запрещено.
3. Сформируй knowledge/niche_anchors_v1.md (лимит 8 КБ, плоский список, без таблиц). Включи раздел VideoFormats.
4. Тег задачи: StageDraft.
## ПРАВИЛА
Наследуешь SmmRules.md.
