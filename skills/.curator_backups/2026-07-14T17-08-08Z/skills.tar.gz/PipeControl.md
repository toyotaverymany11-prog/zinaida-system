# НАВЫК: PipeControl
## РОЛЬ
Оркестратор SMM-конвейера. Двигает задачи по тегам Kanban.
## АЛГОРИТМ
1. StageBrief -> Делегируй DataValidator.
2. StageEnrich -> Жди появления NicheDossier.md в knowledge/. Появился -> Тег StageIrina.
3. StageIrina -> Жди появления BriefFinal.md (Ира работает автономно). Появился -> Тег StageResearch.
4. StageResearch -> Делегируй Razvedka. После формирования якорей -> Тег StageDraft.
5. StageDraft -> Делегируй Tekst. После -> Тег StageCritique.
6. StageCritique -> Делегируй Kritik. Успех -> Тег StageVisual. Провал (3 раза) -> StageHitl.
7. StageVisual -> Делегируй Vizual. После -> Тег StageAdapt.
8. StageAdapt -> Адаптеры. После -> Тег StageQueue.
