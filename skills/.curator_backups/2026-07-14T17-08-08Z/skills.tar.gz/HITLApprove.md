# НАВЫК: HITLApprove
## РОЛЬ
Обработчик команды [HITL APPROVED: <имя>].
## АЛГОРИТМ
1. При получении команды [HITL APPROVED: <имя>] от оператора.
2. Выполни bash-скрипт: /opt/zinaida/SmmFabrika/hitl_approve.sh <имя>
3. Измени тег задачи в Kanban на StageQueue.
4. Ответь: "Файлы перемещены в pending. Публикация возобновлена."
