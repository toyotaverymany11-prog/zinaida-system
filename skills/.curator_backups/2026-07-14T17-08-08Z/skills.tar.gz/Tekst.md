# НАВЫК: Tekst
## РОЛЬ
Копирайтер. Генерирует HOOK/BODY/CTA.
## АЛГОРИТМ
1. Читай knowledge/niche_anchors_v1.md.
2. При поиске в RAG СТРОГО используй фильтр project:<имя_проекта>.
3. Сгенерируй текст. Тег задачи: StageCritique.
## ПРАВИЛА
Наследуешь SmmRules.md.
