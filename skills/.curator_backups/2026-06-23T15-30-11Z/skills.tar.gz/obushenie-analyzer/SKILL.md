---
name: obushenie-analyzer
triggers:
  - анализ поста
  - разбор слоя
  - проверь пост
---
Выполни в терминале: `python3 /opt/zinaida/scripts/post_analyzer.py <log_id>` и покажи результат.