# Skill: Port Check and Restart Service
## Trigger
When port 8000 is unreachable and watchdog reports router crash.
## Steps
1. Check service status: systemctl is-active zinaida_openai_proxy
2. If inactive, restart: systemctl restart zinaida_openai_proxy
3. Wait 5 seconds.
4. Verify port: curl -s http://127.0.0.1:8000/health
5. Log result to incidents.jsonl.
## Rollback
If restart fails, restore previous proxy state from backup.
