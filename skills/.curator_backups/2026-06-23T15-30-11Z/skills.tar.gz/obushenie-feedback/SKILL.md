---
name: obushenie-feedback
triggers:
  - записать фидбек
  - сохранить правки
---
Выполни в терминале: `python3 /opt/zinaida/scripts/record_feedback.py <log_id> 'СЛОЙ X: проблема'`