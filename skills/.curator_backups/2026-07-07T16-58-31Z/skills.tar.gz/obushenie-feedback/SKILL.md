---
name: obushenie-feedback
description: Record post-analysis feedback into the Zinaida learning loop — corrections, layer-level issues, and quality flags. Feeds into the EMA-based curator weights. Integrates with zinaida-content-factory umbrella.
triggers:
  - записать фидбек
  - сохранить правки
  - зафиксировать ошибку
  - feedback
  - исправление
related_skills:
  - zinaida-content-factory
  - obushenie-analyzer
---
# Obushenie Feedback (Запись Фидбека)

## Overview
Feedback recording tool for the **[Zinaida Content Factory](./zinaida-content-factory/)**. Records layer-level corrections after obushenie-analyzer output, which feeds into the EMA-based curator math (Monday weight adjustments).

## Usage
```bash
python3 /opt/zinaida/scripts/record_feedback.py <log_id> 'LAYER: problem description'
```

## Layer Labeling Convention

Use these prefixes for the feedback string:

| Prefix | Layer | Example Problem |
|--------|-------|-----------------|
| `СЛОЙ 0:` | DNA | "голос не Зинаиды, слишком мягко" |
| `СЛОЙ 1:` | Style | "нет честный минус, нет маятника" |
| `СЛОЙ 2:` | Phase | "фаза не соответствует теме" |
| `СЛОЙ 3:` | Attack | "хук слабый, нет цифры в первой строке" |
| `СЛОЙ 4:` | RAG | "чанк не релевантен теме" |
| `СЛОЙ 5:` | CTA | "стрелка отсутствует, команда размыта" |
| `СЛОЙ 6:` | JSON | "формат невалидный" |
| `BLACKLIST:` | — | "мужской глагол 'понял' вместо 'поняла'" |
| `TOKENS:` | — | "превышен лимит 8000" |

## Examples
```bash
# Записать исправление стиля
python3 /opt/zinaida/scripts/record_feedback.py abc123 'СЛОЙ 1: нет рваного ритма, предложения слишком гладкие'

# Записать исправление слоя атаки
python3 /opt/zinaida/scripts/record_feedback.py def456 'СЛОЙ 3: хук открывается с приветствия, не с цифры'

# Записать нарушение чёрного списка
python3 /opt/zinaida/scripts/record_feedback.py ghi789 'BLACKLIST: использовано "важно отметить" во втором абзаце'
```

## Feedback Loop Integration
Recorded feedback accumulates in analytics.db. Every Monday, the curator runs EMA:
```
new_weight = old_weight * 0.8 + target_metric * 0.2
```
This adjusts the Attack Layer weights for the next generation cycle.

## Reference
Full framework documentation: [zinaida-content-factory SKILL.md](./zinaida-content-factory/SKILL.md)
