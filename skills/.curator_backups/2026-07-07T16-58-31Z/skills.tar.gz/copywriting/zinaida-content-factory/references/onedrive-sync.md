# OneDrive Sync — Zinaida Content Factory

## Mounted Remote

```
rclone config name: onedrive (type: personal OneDrive)
Mount service: rclone-onedrive.service (systemd, active)
```

## Key Paths

| Path | Content |
|------|---------|
| `onedrive:/` | Root — contains `Виктория/`, `ИИ/`, `Документы/`, etc. |
| `onedrive:/Виктория/Контент/kontent/` | Main content folder |
| `onedrive:/Виктория/Контент/kontent/dizayner/` | Design assets for Zinaida |
| `onedrive:/Виктория/Контент/kontent/dizayner/zinaida_passport/` | Паспорт лица Зинаиды |
| `zinaida_passport/original/` | Original photos (IMG_0413.PNG, IMG_0415.PNG, IMG_9391.JPG) |
| `zinaida_passport/generated/` | AI-generated rakurse images (push here, not locally) |
| `zinaida_passport/passport.json` | Config for face generation |
| `dizayner/templates/` | Design templates (variant_1_zhurnal.txt, variant_2_tsitata.txt, variant_3_kino.txt) |
| `dizayner/approved/` | Approved final designs |
| `dizayner/oblozhki/` | Cover images |
| `dizayner/test/` | Test variants |
| `dizayner/arkhiv/` | Archive |

## Rclone Config

Config file: `/root/.config/rclone/rclone.conf`
Remote name: `onedrive`
Drive type: personal

## Useful Commands

```bash
# List top-level dirs
rclone lsd onedrive:

# List subdirectory
rclone lsd onedrive:/Виктория/Контент/kontent/

# Tree view
rclone tree onedrive:/Виктория/Контент/kontent/dizayner/

# Copy generated images to sync directory
rclone copy /local/path onedrive:/Виктория/Контент/kontent/dizayner/zinaida_passport/generated/

# Check sync state
systemctl status rclone-onedrive
```

## Rule
Generated AI images for Zinaida's passport should be WRITTEN DIRECTLY to `onedrive:/Виктория/Контент/kontent/dizayner/zinaida_passport/generated/` via rclone, not saved only on the local server. The user checks OneDrive, not the server filesystem.
