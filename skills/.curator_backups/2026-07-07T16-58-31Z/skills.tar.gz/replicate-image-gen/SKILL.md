---
name: replicate-image-gen
description: "Генерация изображений через Replicate API (FLUX, Recraft, Ideogram). Токен в REPLICATE_API_TOKEN."
version: 1.0.0
author: Zinaida-System
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [replicate, image-generation, flux, recraft, ideogram]
---

# Replicate Image Generation

## Модели
1. **FLUX Dev** (`black-forest-labs/flux-dev`) — $0.025/img — фотореализм
2. **Recraft V3** (`recraft-ai/recraft-v3`) — $0.04/img — дизайн, текст
3. **Ideogram V3** (`ideogram-ai/ideogram-v3`) — $0.08/img — текст на картинках

## Быстрый старт
```python
import replicate, os
os.environ["REPLICATE_API_TOKEN"] = os.getenv("REPLICATE_API_TOKEN")
output = replicate.run("black-forest-labs/flux-dev", input={
    "prompt": "your prompt here",
    "guidance": 3.5,
    "num_inference_steps": 28,
    "width": 1024, "height": 1024,
    "output_format": "png"
})
```

## Реалистичная кожа
Добавляй к промптам портретов:
`Ultra-realistic skin with visible pores, natural imperfections, subsurface scattering`

## Бюджет
$10 = ~400 генераций FLUX Dev или ~250 Recraft V3
