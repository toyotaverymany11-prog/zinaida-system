---
name: obushenie-analyzer
description: Analyze a generated post from the Zinaida content factory — check layers, style compliance, blacklist violations, and metrics. Integrates with zinaida-content-factory umbrella.
triggers:
  - анализ поста
  - разбор слоя
  - проверь пост
  - проанализируй пост
  - анализ слоёв
related_skills:
  - zinaida-content-factory
  - obushenie-feedback
---
# Obushenie Analyzer (Разборщик Постов)

## Overview
Post-analysis tool for the **[Zinaida Content Factory](./zinaida-content-factory/)**. Checks a generated post against all 7 layers of the assembly pipeline, the "Шквальный" style rules, and the blacklist.

## Usage
```bash
python3 /opt/zinaida/scripts/post_analyzer.py <log_id>
```

Where `<log_id>` is the post ID from the generation queue or content_rotation.db.

## What It Analyzes

### Layer-by-Layer Check
1. **Layer 0 (DNA):** Does the voice match Zinaida's character?
2. **Layer 1 (Style):** Does it follow the 16 "Шквальный" rules?
3. **Layer 2 (Phase):** Is the correct relationship phase identified?
4. **Layer 3 (Attack):** Hook + stats + micro-story present and welded?
5. **Layer 4 (RAG):** Was RAG knowledge used appropriately?
6. **Layer 5 (CTA):** Pain dictionary + arrow CTA present?
7. **Layer 6 (JSON):** Output format correct?

### Blacklist Scan
Scans for:
- Bold dots (•, ●)
- Long dashes (—)
- Trailing ellipsis (...)
- Filler phrases ("давайте разберёмся", "важно отметить", "стоит понимать")
- Amplifiers ("это не просто", "больше чем просто", "не только но и")
- Meta-commentary ("надеюсь поможет", "подводя итог")
- Masculine verbs (понял, сделал instead of поняла, сделала)
- AI self-reference ("как языковая модель")

### Metrics Check
- Token count (hard cap: 8000)
- Pendulum pattern (plus → minus → plus)
- честный минус block present
- Open Loop at end

## Output
Returns a structured report with:
- PASS/FAIL per layer
- Blacklist violations (if any)
- Style compliance score
- Token budget status
- Suggested fixes

## Reference
Full framework documentation: [zinaida-content-factory SKILL.md](./zinaida-content-factory/SKILL.md)
