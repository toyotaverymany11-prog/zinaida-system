# HyperFrames Workflow Guide

## Overview

HyperFrames treats HTML as the source of truth for video generation. You build compositions as HTML/CSS/JS documents, validate them, then render to MP4 using FFmpeg.

## Architecture

```
Composition (HTML/CSS/JS)
    ↓
HyperFrames Runtime (GSAP, FFmpeg)
    ↓
MP4 Video Output
```

## Project Structure

```
my-video/
├── src/
│   ├── index.html          # Root composition
│   ├── styles.css          # Global styles
│   ├── animations.js       # GSAP timelines
│   ├── scenes/             # Scene components
│   │   ├── hero.html
│   │   ├── intro.html
│   │   └── outro.html
│   └── assets/             # Images, fonts, audio
│       ├── logo.png
│       └── background.jpg
├── out/                    # Rendered outputs
│   ├── draft.mp4
│   └── final.mp4
├── .hyperframesrc          # Configuration
└── package.json            # Dependencies
```

## Composition Anatomy

### Root Element

```html
<div
  data-composition-id="main"
  data-width="1920"
  data-height="1080"
  data-fps="30"
  data-duration="10"
>
  <!-- Content -->
</div>
```

### Scene Structure

```html
<!-- Scene 1: Hero -->
<div
  data-start="0"
  data-duration="3"
  data-track-index="0"
>
  <h1>Welcome to My Video</h1>
</div>

<!-- Scene 2: Content -->
<div
  data-start="3"
  data-duration="4"
  data-track-index="1"
>
  <p>This is the main content area</p>
</div>
```

## CSS Layout Best Practices

### Viewport Units

```css
/* Use vh/vw for responsive layouts */
.hero {
  width: 80vw;
  height: 60vh;
  margin: 20vh auto;
}

/* Safe zones */
.text-safe-zone {
  padding: 5vh 5vw;
}
```

### Typography

```css
/* Mobile-first typography */
h1 {
  font-size: clamp(2rem, 5vw, 4rem);
  line-height: 1.2;
  font-weight: 700;
  color: white;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
}

p {
  font-size: clamp(1rem, 2.5vw, 1.5rem);
  line-height: 1.4;
}
```

### Colors and Contrast

```css
:root {
  --primary: #00ff88;
  --background: #0a0a0a;
  --text: #ffffff;
}

body {
  background-color: var(--background);
  color: var(--text);
}

.high-contrast {
  color: black;
  background-color: white;
}
```

## JavaScript Animation

### GSAP Timelines

```javascript
// Register timeline on window
window.__timelines = window.__timelines || {};

window.__timelines.hero = gsap.timeline({
  defaults: { ease: "power2.out" }
})
  .from("h1", { y: 100, opacity: 0, duration: 1 })
  .to("h1", { color: "#00ff88", duration: 2 }, ">=0.5")
  .to(".hero-bg", { scale: 1.1, duration: 3 }, 0);
```

### Frame-Based Timing

```javascript
// Use frame numbers, not time
const frame = useCurrentFrame();
const videoConfig = useVideoConfig();

// Calculate position in timeline
const progress = frame / (videoConfig.duration * videoConfig.fps);
```

### Asset Loading

```javascript
// Preload assets
const logo = new Image();
logo.src = "assets/logo.png";

// Use in animation
gsap.to(".logo", {
  opacity: 1,
  duration: 0.5,
  onStart: () => logo.style.display = "block"
});
```

## Common Composition Patterns

### Hero Section

```html
<div class="hero" data-start="0" data-duration="4">
  <div class="hero-content">
    <img src="assets/logo.svg" class="logo" alt="Logo">
    <h1>Product Name</h1>
    <p>Tagline goes here</p>
  </div>
  <div class="hero-bg"></div>
</div>

<style>
.hero {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.hero-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  z-index: -1;
}

.logo {
  width: 200px;
  height: auto;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}
</style>
```

### Text Animation

```javascript
window.__timelines.text = gsap.timeline()
  .from(".text-line", {
    y: 50,
    opacity: 0,
    stagger: 0.2,
    duration: 0.8,
    ease: "back.out(1.7)"
  })
  .to(".text-line", {
    color: "#00ff88",
    duration: 1,
    stagger: 0.2
  }, ">=0.5");
```

### HUD/Tech Visuals

```html
<div class="hud" data-start="2" data-duration="6">
  <div class="hud-item">CPU: <span id="cpu">85%</span></div>
  <div class="hud-item">MEM: <span id="mem">6.2GB</span></div>
  <div class="hud-item">NET: <span id="net">12.4 Mbps</span></div>
</div>

<style>
.hud {
  position: absolute;
  top: 20px;
  right: 20px;
  font-family: 'Courier New', monospace;
  font-size: 14px;
  color: #00ff88;
  background: rgba(0,0,0,0.7);
  padding: 10px;
  border-radius: 5px;
  backdrop-filter: blur(5px);
}

.hud-item {
  margin: 5px 0;
}
</style>
```

## Validation Commands

### Linting

```bash
npx hyperframes lint
```

Checks for:
- Valid HTML structure
- Required data attributes
- GSAP timeline registration
- CSS syntax errors
- Asset file existence

### Inspection

```bash
npx hyperframes inspect --samples 20
```

Renders 20 sample frames and saves to `out/inspection/` for review. Use to verify:
- Layout at different timestamps
- Animation smoothness
- Text readability
- Color consistency
- Asset loading

### Preview

```bash
npx hyperframes preview
```

Starts a local server at `http://localhost:3000` for interactive preview. Use to:
- Test interactivity
- Check responsive behavior
- Validate timing
- Iterate quickly

## Rendering

### Quality Levels

```bash
# Fast iteration (lower quality)
npx hyperframes render --output draft.mp4 --quality draft

# Standard quality (good balance)
npx hyperframes render --output final.mp4 --quality standard

# High quality (final delivery)
npx hyperframes render --output hd.mp4 --quality high
```

### Custom Output

```bash
# Specific duration
npx hyperframes render --duration 15 --output custom.mp4

# Custom framerate
npx hyperframes render --fps 60 --output smooth.mp4

# Custom resolution
npx hyperframes render --width 1920 --height 1080 --output hd.mp4
```

### Batch Rendering

```bash
# Render multiple compositions
for comp in src/scenes/*.html; do
  name=$(basename ${comp%.html})
  npx hyperframes render --composition "$name" --output "out/${name}.mp4"
done
```

## Performance Optimization

### Animation Tips

1. **Use CSS transforms**: `transform: translateX()` is GPU-accelerated
2. **Avoid layout thrashing**: Batch DOM reads/writes
3. **Use will-change**: Hint browser about animations
4. **Limit active animations**: Only animate what's visible

```css
.element {
  will-change: transform, opacity;
}
```

### Asset Optimization

```bash
# Convert images to WebP
guetzli input.jpg output.webp

# Compress audio
ffmpeg -i audio.mp3 -c:a libopus -b:a 96k audio.opus

# Use sprites for icons
```

### Code Splitting

```javascript
// Load scenes dynamically
const scenes = [
  () => import('./scenes/hero.js'),
  () => import('./scenes/content.js'),
  () => import('./scenes/outro.js')
];

// Initialize only current scene
await scenes[currentScene]();
```

## Debugging

### Common Issues

**Black frames**: Check FFmpeg installation and codecs
```bash
ffmpeg -version
```

**Layout issues**: Use inspection mode
```bash
npx hyperframes inspect --samples 30
```

**Animation not working**: Verify GSAP timeline registration
```javascript
if (!window.__timelines || !window.__timelines.main) {
  console.error("Timeline not registered!");
}
```

**Missing assets**: Check file paths are absolute or relative to project root

### Diagnostic Commands

```bash
# Check dependencies
npx hyperframes doctor

# List available compositions
npx hyperframes list

# Get composition info
npx hyperframes info --composition main

# Validate specific composition
npx hyperframes validate --composition hero
```

## Deployment

### Output Structure

```
out/
├── draft.mp4              # Quick iteration
├── final.mp4              # Standard quality
├── hd.mp4                 # High quality
├── inspection/            # Frame samples
│   ├── frame_0001.png
│   ├── frame_0002.png
│   └── ...
└── assets/                # Rendered assets
    ├── fonts/            # Converted fonts
    └── images/           # Optimized images
```

### Platform-Specific Settings

**YouTube (1080p)**:
```bash
npx hyperframes render --width 1920 --height 1080 --fps 30 --output youtube.mp4
```

**Instagram Reels (9:16)**:
```bash
npx hyperframes render --width 1080 --height 1920 --fps 30 --output reels.mp4
```

**TikTok (9:16)**:
```bash
npx hyperframes render --width 1080 --height 1920 --fps 30 --output tiktok.mp4
```

**Twitter/X (16:9)**:
```bash
npx hyperframes render --width 1280 --height 720 --fps 30 --output twitter.mp4
```

## Best Practices

1. **Start with static layout**: Get HTML/CSS working before adding animation
2. **Use semantic HTML**: `<section>`, `<article>`, proper heading hierarchy
3. **Accessibility**: Add `aria-label` to interactive elements
4. **Responsive design**: Test on multiple screen sizes
5. **Performance budget**: Keep total JS < 100KB, images < 2MB
6. **Version control**: Commit before major changes
7. **Documentation**: Add comments for complex animations

## Example Projects

- **Product Demo**: Hero section with feature highlights
- **Tutorial Video**: Step-by-step with callouts
- **Social Media Ad**: Quick hook + CTA
- **Motion Graphic**: Abstract shapes and transitions
- **HUD Display**: Real-time data visualization
- **Webinar Intro**: Speaker introduction with branding

---

## Quick Reference

| Task | Command |
|------|---------|
| Initialize project | `npx hyperframes init my-video` |
| Validate | `npx hyperframes lint` |
| Inspect | `npx hyperframes inspect --samples 20` |
| Preview | `npx hyperframes preview` |
| Render | `npx hyperframes render --output video.mp4` |
| Doctor | `npx hyperframes doctor` |
| List compositions | `npx hyperframes list` |
