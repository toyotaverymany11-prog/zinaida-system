# xAI Grok Image-to-Video Reference

## Overview

The xAI Grok image-to-video endpoint animates static images into short videos using xAI's Grok model. This is accessed through Hermes Web UI's media endpoints.

## Authentication Setup

### Token Resolution Priority

1. `AUTH_TOKEN` environment variable
2. `${HERMES_WEB_UI_HOME}/.token`
3. `${HERMES_WEBUI_STATE_DIR}/.token`
4. `~/.hermes-web-ui/.token`

### xAI Credentials

Required for successful generation:
- `XAI_API_KEY` environment variable, OR
- Complete xAI OAuth login in Hermes Web UI

If you see `code: "missing_xai_token"`, set up xAI credentials first.

## Base URL Resolution

```bash
# Priority order:
1. HERMES_WEB_UI_URL environment variable
2. http://127.0.0.1:${PORT} (if PORT is set)
3. http://127.0.0.1:8648 (default dev port)
4. http://127.0.0.1:6060 (Docker default)
```

## Endpoint Details

```
POST <base-url>/api/hermes/media/grok-image-to-video
Headers:
- Authorization: Bearer <token>
- X-Hermes-Profile: <profile-name> (optional)
- Content-Type: application/json

Body:
{
  "image_path": "/absolute/path/to/image.png",
  "prompt": "Motion description",
  "duration": 8,           // seconds (1-15)
  "output_path": "/path/to/output.mp4",  // optional
  "timeout_ms": 600000     // default 600000ms
}
```

## Prompt Engineering Guide

### Motion Styles

**Cinematic:**
- "Slow cinematic push-in with shallow depth of field"
- "Dolly zoom effect, subtle camera shake"
- "Orbital camera movement around the subject"

**Natural:**
- "Gentle breathing motion, like a sleeping person"
- "Subtle wind through hair and clothing"
- "Water ripples on surface"

**Dynamic:**
- "Fast tracking shot following the subject"
- "Explosive energy radiating outward"
- "Camera whip pan to reveal new scene"

### Style Modifiers

- Add "in the style of [artist/film]" for specific aesthetics
- "hyperrealistic" or "photorealistic" for quality
- "animated" or "cartoon" for stylized results
- "8k quality" or "ultra HD" for resolution emphasis

## Common Parameters

| Parameter | Type | Default | Range | Description |
|-----------|------|---------|-------|-------------|
| image_path | string | required | - | Absolute path to PNG/JPEG/WebP |
| prompt | string | required | - | Motion and style instructions |
| duration | number | 8 | 1-15 | Video duration in seconds |
| output_path | string | auto-generated | - | Where to save MP4 |
| timeout_ms | number | 600000 | - | Max wait time in ms |

## Error Codes

| Code | Meaning | Solution |
|------|---------|----------|
| missing_xai_token | No xAI credentials | Set XAI_API_KEY or login in Web UI |
| 401 | Unauthorized | Check token and profile headers |
| 403 | Forbidden | Verify Hermes Web UI is running |
| connection_failed | Network issue | Check Hermes Web UI URL |
| timeout | Generation took too long | Increase timeout_ms or retry |

## Example Workflows

### Quick Animation

```bash
# Setup token
TOKEN=$(cat ~/.hermes-web-ui/.token)
BASE_URL="http://127.0.0.1:6060"

# Generate
curl -sS -X POST "$BASE_URL/api/hermes/media/grok-image-to-video" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "image_path": "/home/user/photos/portrait.jpg",
    "prompt": "Slow cinematic push-in, shallow depth of field, 8k quality",
    "duration": 8,
    "output_path": "/home/user/videos/portrait-animation.mp4"
  }'
```

### Batch Processing

```bash
# Generate multiple videos from a directory
for img in /path/to/images/*.png; do
  output="/path/to/outputs/$(basename ${img%.png}).mp4"
  curl ... -d "{\"image_path\": \"$img\", \"prompt\": \"cinematic motion\", ... }" > /dev/null
  echo "Generated: $output"
done
```

## Performance Tips

1. **Image Quality**: Use high-resolution images (1080p+) for best results
2. **Prompt Clarity**: Be specific about motion direction and style
3. **Duration**: Shorter videos (4-8s) generate faster and look more natural
4. **Retry**: If generation fails, wait 30s and retry (xAI rate limits may apply)

## Output Validation

After generation, verify:
- MP4 file exists at specified path
- Duration matches requested duration (±0.5s)
- Motion is visible and matches prompt
- No artifacts or corruption

## Platform-Specific Settings

### Vertical Video (9:16)
```json
{
  "prompt": "Vertical composition, cinematic push-in",
  "duration": 9
}
```

### Horizontal Video (16:9)
```json
{
  "prompt": "Horizontal composition, slow tracking shot",
  "duration": 10
}
```

### Square Video (1:1)
```json
{
  "prompt": "Square composition, centered subject",
  "duration": 6
}
```

## Advanced: Custom Output Paths

```bash
# Organize by date
output_path="/videos/$(date +%Y-%m-%d)/${filename}.mp4"

# Use environment variable
output_path="${OUTPUT_DIR:-/tmp}/output.mp4"

# Relative to project
output_path="out/animations/${filename}.mp4"
```
