---
name: ai-video-generation
description: "Create AI-generated videos using multiple approaches: xAI Grok Imagine, HyperFrames (HTML/CSS/JS), and Remotion (React). Use for short videos, animations, product demos, tutorials, and motion graphics."
version: 1.0.0
author: Hermes Curator
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [ai-video, video-generation, grok, hyperframes, remotion, media]
prerequisites:
  commands: [curl, node, npx]
---

# AI Video Generation

This umbrella skill covers three distinct approaches to AI-powered video generation:

1. **xAI Grok Imagine** - Generate videos from images using xAI's Grok model via Hermes Web UI
2. **HyperFrames** - Create HTML/CSS/JS compositions that render to MP4
3. **Remotion** - Build React-based video projects with code

Use this skill when the user wants to create videos, animations, or motion graphics using AI techniques.

## Choosing the Right Approach

| Approach | Best For | Requirements | Output |
|----------|----------|--------------|--------|
| **xAI Grok Imagine** | Quick video generation from images, cinematic motion | Hermes Web UI with xAI credentials | MP4 video |
| **HyperFrames** | HTML/CSS/JS-based motion graphics, HUD elements, web-to-video | Node.js, FFmpeg | MP4 video |
| **Remotion** | React-based video projects, editable templates, complex animations | Node.js, React | MP4 video + React project |

### Use xAI Grok when:
- User has an image they want to animate
- They want quick, prompt-driven video generation
- They need cinematic motion effects
- They're using Hermes Web UI with xAI integration

### Use HyperFrames when:
- User wants to create HTML/CSS/JS-based compositions
- They need HUD/tech visuals or motion graphics
- They prefer declarative layout with animation
- They want to convert web content to video

### Use Remotion when:
- User wants editable, code-based video projects
- They need React components for scenes and animations
- They want reusable video templates
- They need fine-grained control over timing and composition

## Workflow

1. **Clarify the brief**: duration, aspect ratio, style, target platform
2. **Select the approach** based on the criteria above
3. **Execute the workflow** for the chosen approach
4. **Deliver** the rendered video and project files

## xAI Grok Image-to-Video

See: `references/grok-image-to-video.md`

### Quick Start

```bash
# Set up token resolution
TOKEN="${AUTH_TOKEN:-}"
if [ -z "$TOKEN" ] && [ -n "${HERMES_WEB_UI_HOME:-}" ] && [ -f "$HERMES_WEB_UI_HOME/.token" ]; then
  TOKEN="$(cat "$HERMES_WEB_UI_HOME/.token")"
fi

# Call the endpoint
curl -sS -X POST "$BASE_URL/api/hermes/media/grok-image-to-video" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{
    "image_path": "/path/to/image.png",
    "prompt": "Animate with cinematic push-in",
    "duration": 8,
    "output_path": "/path/to/output.mp4"
  }'
```

## HyperFrames Video Generation

See: `references/hyperframes-workflow.md`

### Quick Start

```bash
# Install if needed
hermes skills install official/creative/hyperframes

# Initialize project
npx hyperframes init my-video --non-interactive

# Write composition (HTML/CSS/JS)
# ...

# Validate
npx hyperframes lint
npx hyperframes inspect --samples 15

# Preview
npx hyperframes preview

# Render
npx hyperframes render --output final.mp4 --quality high
```

## Remotion Video Generation

See: `references/remotion-workflow.md`

### Quick Start

```bash
# Create project
npx create-video@latest --yes --blank my-video

# Build compositions (React components)
# ...

# Preview
npx remotion studio

# Render
npx remotion render <composition-id> out/final.mp4
```

## Validation Checklist

Before delivering any video project, verify:

- [ ] Video renders without errors
- [ ] Duration matches brief (or user's request)
- [ ] Aspect ratio is correct for target platform
- [ ] Text is readable (high contrast, safe margins)
- [ ] Audio (if any) is properly synced
- [ ] Output path is accessible and correct
- [ ] All assumptions are documented

## Delivery Format

When delivering a completed video project, include:

1. **Rendered MP4 path** (the final deliverable)
2. **Project files path** (if applicable - HyperFrames/Remotion projects)
3. **Preview command** or Studio URL
4. **Composition ID** used for rendering (Remotion)
5. **Assumptions made** about duration, style, assets, etc.
6. **Next steps** for editing or iteration

## Troubleshooting

### Common Issues

**xAI Grok**:
- `missing_xai_token`: Set `XAI_API_KEY` or complete xAI OAuth in Hermes Web UI
- 401/403 errors: Check Hermes Web UI token and profile headers
- Connection failures: Verify Hermes Web UI is running and accessible

**HyperFrames**:
- Missing Node.js/FFmpeg: Install dependencies
- Render failures: Run `npx hyperframes doctor`
- Layout issues: Use `inspect` command to check frames

**Remotion**:
- Missing browser/codecs: Install Chrome and FFmpeg
- Build errors: Run `npm run build` before rendering
- Preview issues: Check Studio server status

### Fallback Strategy

If one approach fails or is unavailable:
1. Try a different approach within this umbrella
2. Suggest manual editing/iteration
3. Document limitations and workarounds

---

## References

- `references/grok-image-to-video.md` - Detailed Grok workflow and troubleshooting
- `references/hyperframes-workflow.md` - HyperFrames setup and composition guide
- `references/remotion-workflow.md` - Remotion project structure and best practices
- `references/video-style-guide.md` - Style recommendations and platform specs
- `references/troubleshooting.md` - Common errors and solutions

## Templates

- `templates/grok-prompt-guide.md` - Prompt templates for Grok video generation
- `templates/hyperframes-composition.html` - Base HTML template
- `templates/remotion-composition.tsx` - Base React component
- `templates/video-brief-template.md` - Project brief template

## Scripts

- `scripts/validate-video.sh` - Validate video output (duration, codec, path)
- `scripts/extract-frames.sh` - Extract frames for review
- `scripts/calculate-duration.py` - Calculate optimal duration based on content